import woordle_methods

def main():
    woordle_methods.solver()

if __name__ == "__main__":
    main()